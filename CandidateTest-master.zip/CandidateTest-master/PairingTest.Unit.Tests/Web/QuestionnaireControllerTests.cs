﻿using NUnit.Framework;
using PairingTest.Web.Controllers;
using PairingTest.Web.Models;
using PairingTest.Web.QuestionnaireService;
using System.Web.Mvc;


namespace PairingTest.Unit.Tests.Web
{
  [TestFixture]
  public class QuestionnaireControllerTests
  {
    [Test]
    public void ShouldGetQuestions()
    {
      //Arrange
      var expectedTitle = "Geography Questions";
      IQuestionnaireService service = new QuestionnaireService();
      var questionnaireController = new QuestionnaireController(service);

      //Act
      var result = (QuestionnaireViewModel)questionnaireController.Index().ViewData.Model;

      //Assert
      Assert.That(result.QuestionnaireTitle, Is.EqualTo(expectedTitle));
    }

  }
}

