﻿using Newtonsoft.Json;
using PairingTest.Web.Models;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Configuration;

namespace PairingTest.Web.QuestionnaireService
{
  public class QuestionnaireService : IQuestionnaireService
  {
    readonly string baseUri = ConfigurationManager.AppSettings["QuestionnaireServiceUri"];

    public QuestionnaireViewModel GetQuestions()
    {
      using (HttpClient httpClient = new HttpClient())
      {
        Task<String> response = httpClient.GetStringAsync(baseUri);
        return JsonConvert.DeserializeObjectAsync<QuestionnaireViewModel>(response.Result).Result;
      }
    }
  }
}