﻿using PairingTest.Web.Models;

namespace PairingTest.Web.QuestionnaireService
{
  public interface IQuestionnaireService
  {
    QuestionnaireViewModel GetQuestions();
  }
}
