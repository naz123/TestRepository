﻿using PairingTest.Web.Models;
using PairingTest.Web.QuestionnaireService;
using System.Web.Mvc;

namespace PairingTest.Web.Controllers
{
  public class QuestionnaireController : Controller
  {
    private readonly IQuestionnaireService _service;

    public QuestionnaireController(IQuestionnaireService service)
    {
      _service = service;
    }

    public ViewResult Index()
    {
      QuestionnaireViewModel model = _service.GetQuestions();
      ViewData["questionaire"] = model;
      return View(model);
    }
  }
}
