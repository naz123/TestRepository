namespace QuestionServiceWebApi.Interfaces
{
  public interface IQuestionRepository
  {
    Questionnaire GetQuestionnaire();
  }
}